<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<!-- 
    version 0.9.8
 -->
<html lang="en" style="overflow:hidden;height:100%">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
    <link rel="icon" href="../dist/logo.ico">
    <title>Tips Bola Jalan-Prediksi Workld Cup 2018</title>
</head>
<body scroll="no" style="margin:0;padding:0;overflow:hidden;position: relative;touch-action: none;">
    <div id="app"></div>
    <script src="assets/build.js"></script>
</body>
</html>